# AIOS Proj3 R6.2.1 发布修订

请先读 [发布复核说明](PUBLICATION_REVIEW.md) 与 [部署验收手册](02_acceptance/OPEN_EULER_RUNBOOK.md)。

完整交付包含原始 NUC 绑定源包、修正文档后的源码、报告/PPT与原始证据。使用 `python3 -m zipfile -e` 解压；`python3 02_acceptance/verify_delivery.py .` 校验全部内容。离线验收脚本仍执行原始 f4cbc 源包，不混淆版本绑定。

报告/PPT保留 R6 系列历史记录；新增实验的限制以 PUBLICATION_REVIEW.md 为准。视频和签字仍待团队完成。
