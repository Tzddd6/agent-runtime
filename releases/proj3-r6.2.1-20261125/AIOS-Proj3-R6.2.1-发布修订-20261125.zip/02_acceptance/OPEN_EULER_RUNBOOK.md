# openEuler 24.03 SP4 干净部署与安全验收手册（R6 111 项正式封板版）

## 1. 解压与完整性校验
> ⚠️ **重要提示（openEuler `unzip 6.00` 兼容说明）**：openEuler 自带的 `unzip 6.00`（2009 年版本）会忽略 ZIP 内的 UTF-8 文件名标志导致中文文件名乱码，**请务必使用 `python3 -m zipfile -e` 或 `7z x` 解压，切勿直接使用 `unzip`**！
```bash
mkdir -p ~/aios-proj3-final
python3 -m zipfile -e AIOS-Proj3-R6.2.1-发布修订-20261125.zip ~/aios-proj3-final
cd ~/aios-proj3-final
python3 02_acceptance/verify_delivery.py .
```

## 2. 环境与依赖说明（Python 3.11+）
内核基础功能主要依赖 Python 3.11+ 标准库（`sqlite3`、`urllib`、`socket`、`multiprocessing` 等，包内不包含 `requirements.txt`）；**完整附件功能（PDF/图片解析）及对应测试需要 `pymupdf`、`pillow`；Linux 硬隔离测试需要 `cgroup v2` 委派环境**。

在干净环境中建议创建虚拟环境并安装附件依赖：
```bash
python3 -m venv ~/aios-venv && source ~/aios-venv/bin/activate
pip install pymupdf pillow
```
`FINAL_CHECK.sh` 会自动解析当前激活环境（或环境变量 `AIOS_PYTHON`）的 Python 绝对路径，并显式传递给 `systemd-run --user`，避免 `systemd-run` 退回系统默认解释器。

## 3. 一键离线全量验收并导出日志到包外目录（111 项 + cgroup v2 硬隔离 + 零残留）
为避免覆盖包内受 `FILES.sha256` 校验的归档证据文件，请务必将新生成的验收日志导出到**包外目录**并启用 `set -o pipefail`：
```bash
set -o pipefail
bash 02_acceptance/FINAL_CHECK.sh 2>&1 | tee "/tmp/aios-proj3-acceptance-$(date +%Y%m%d-%H%M%S).log"
```
- **安全临时目录**：脚本自动在 `/tmp/aios-proj3-accept.XXXXXX` 创建隔离临时目录并在退出时 `trap` 清理，不会删除用户任何已有目录。
- **零付费调用**：离线验收不依赖任何云端模型 API Key，全部使用本地受控桩与真实 Linux 内核原语（`cgroup v2` 委托子树初始化、`AF_UNIX`、`unshare`）。
- **通过标志**：
  - 第一阶段（委托 `cgroup v2` 下执行 `unittest`）：`Ran 111 tests ... OK`（0 跳过）；
  - 第二阶段（`validate_linux.py`）：发现 111 项（其中 1 项委派专项因独立进程环境跳过）并完成独立 Linux `cgroup v2` 硬限流/OOM/零孤儿目录验证，输出 `zero_orphan_cgroups: true` 与 `=== AIOS_PROJ3_ACCEPTANCE_PASSED ===`。
- **随包实机日志**：
  - 当前 R6 版本绑定 111 项实机日志（对应源码 SHA `f4cbc22d4b64a348726f9860cdc13f2c6162e0eee91fef33dead263237b8a1c8`）：[`02_acceptance/nuc_final_check_111tests_r6_20261125.log`](./nuc_final_check_111tests_r6_20261125.log)；
  - 历史 2026-11-24 R3 108 项实机日志（仅供追溯）：[`02_acceptance/nuc_final_check_108tests_historical_20261124.log`](./nuc_final_check_108tests_historical_20261124.log)；
  - 历史 2026-11-23 89 项基线实机日志（仅供追溯）：[`02_acceptance/nuc_final_check_89tests_historical_20261123.log`](./nuc_final_check_89tests_historical_20261123.log)。请勿覆盖。

## 4. Web Console 安全启动与演示规范
```bash
# 解压冻结源码并启动（runtime.web 已固定绑定 127.0.0.1，不支持 --host 参数）
python3 -m zipfile -e 01_source/aios-proj3-v2.0-FROZEN.zip /tmp/aios-web-demo
cd /tmp/aios-web-demo
python3 -m runtime.web --port 8765
```
- 远程访问请使用 SSH 本地端口转发（当前 NUC 端口为 `2222`，无密码示例，前提是远端已按上述命令在 `8765` 端口启动本冻结版本，不代表生产站点已自动切换）：
  ```bash
  ssh -p 2222 -L 8765:127.0.0.1:8765 tzd@mc.tzddd.cn
  ```
  随后在本地浏览器打开 `http://127.0.0.1:8765/console/`。
- **在线真实模型配置方式（与当前代码一致）**：当前 `ModelService` 启动时创建空 Profile Broker，**仅设置 `DEEPSEEK_API_KEY` 环境变量不会自动将 Web 状态置为 `configured=true`**。如需在线真实模型演示，请在启动网页后进入 **“模型与 API”** 面板，显式**保存并选择**供应商配置；密钥仅由独立 `ModelService` 进程内存持有（业务子进程环境变量不继承供应商 Key），服务重启后需重新输入。录屏时请隐藏密钥输入过程，禁止写入配置文件或终端回显。

## 5. 能力边界说明
1. **桌面控制（LiteCUA / `VMController`）**：当前为内存态无障碍树与 GUI 状态机模拟沙箱，未接管 NUC 物理桌面。
2. **基准口径**：5 套公开任务子集 + 1 套合成压测均在自托管受控框架下运行，不代表官方榜单成绩。
3. **性能边界**：加速数据仅覆盖多路并发云端实测场景；在本次 openEuler 24.03 NUC 固定响应桩、单并发、四工程链路公平交替对照（`06_evidence/nuc_fair_interleaved_r6_111tests.json`）中，AIOS Runtime 耗时中位数比直接编排多 `+85.8~87.0ms`（`+6.1%~+7.6%`，仍略慢），尚未证明在所有场景下均快于直接调用。

## R6.2.1 发布修订
见 [发布复核说明](../PUBLICATION_REVIEW.md)。完整校验不再跳过中文文件；FINAL_CHECK 继续执行原始 NUC 绑定源包。更新 README/图的源码见 `01_source/aios-proj3-r6.2.1-PUBLISHED.zip`。本轮未重跑 NUC。

## R6.2.1 发布修订
见 [发布复核说明](../PUBLICATION_REVIEW.md)。完整校验不再跳过中文文件；FINAL_CHECK 继续执行原始 NUC 绑定源包。更新 README/图的源码见 `01_source/aios-proj3-r6.2.1-PUBLISHED.zip`。本轮未重跑 NUC。
