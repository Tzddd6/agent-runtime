# AIOS Proj3 实机验收状态与封板签字表（R6 111 项正式封板）

- **当前冻结源包 SHA-256**：`f4cbc22d4b64a348726f9860cdc13f2c6162e0eee91fef33dead263237b8a1c8`（`01_source/aios-proj3-v2.0-FROZEN.zip`，版本标识 `aios-proj3-v2.2-R6-111tests-FROZEN`）

| 验收维度 | 实机结果（openEuler 24.03 SP4） | 随包证据路径 | 状态 |
|---|---|---|---|
| R6 同持久性优化全量单元测试（111 项：含 Linux `cgroup v2`、`AF_UNIX`、15 项边界、5 项护栏、5 项复核、9 项 R3 及 3 项 R6 回滚/停启不变式） | **第一阶段 111/111 通过（17.069s，0 跳过）**；第二阶段发现 111 项（14.852s，1 项委派专项跳过）并完成独立 Linux 硬隔离验证 | [`nuc_final_check_111tests_r6_20261125.log`](./nuc_final_check_111tests_r6_20261125.log)（历史 108/89 项日志均已标明历史保留） | PASS |
| `validate_linux.py` 硬隔离验证 | `cpu_core_ratio = 0.2075` (`nr_throttled = 21`), `oom_kill = 1`, `zero_orphan_cgroups = true`, `proj3_e2e = passed` | [`nuc_final_check_111tests_r6_20261125.log`](./nuc_final_check_111tests_r6_20261125.log) | PASS |
| 浏览器端到端下载复测（本机）+ NUC 真实 PID/cgroup 回执（两次独立运行） | ① 本机 Chromium 真实点击 `order_service` 修复并下载交付 ZIP，解压空目录运行 3 项公开 `unittest` 全绿；② NUC 委托 `cgroup v2` 独立运行留存真实 `tester_agent` PID 与 `cgroup_v2` 路径回执，内核关闭后 `zero_orphan_cgroups_after_kernel_close = true` | [`../06_evidence/r6_browser_download_retest_evidence.json`](../06_evidence/r6_browser_download_retest_evidence.json) & [`../06_evidence/nuc_real_cgroup_receipts_order_service_r6.json`](../06_evidence/nuc_real_cgroup_receipts_order_service_r6.json) | PASS |
| NUC Linux 完整公平交替对照（固定响应桩，单并发，四工程链路，同持久性 `fsync` + `FULL`） | 双方每轮输入 SHA 逐对一致（`same_prompt_hash_by_pair = [true, true, true]`），各 12/12 完成；本次观测中 Runtime 比直接编排多 `+85.8~87.0ms`（`+6.1%~+7.6%`，仍略慢，且不产生真实计费 Token，不据此宣称速度或费用优势） | [`../06_evidence/nuc_fair_interleaved_r6_111tests.json`](../06_evidence/nuc_fair_interleaved_r6_111tests.json) | PASS（边界透明） |
| 多路复用 `ModelService` 并发（2026-11-23 真实 DeepSeek） | 4 并发 `0.542s`（相对旧版单 Pipe 锁提速 9.07×），8 并发 `8/8` (`1.115s`) | [`../06_evidence/real_gaps_closed_nuc.json`](../06_evidence/real_gaps_closed_nuc.json) | PASS |
| 5 套公开任务子集 + 1 套合成压测（2026-11-23 Bare 对照） | 200 并发合成压测 `200/200` (`0.1076s`)；云端全量零 `502`；BFCL 比 Bare 快 1.66×、AgentBench 比 Bare 快 1.88×（追平 16/26）、tau2 相对旧版串行 AIOS 提速 3.18×（16/20→15/20 如实记录） | [`../06_evidence/扩量公开基准与全功能对比报告-2026-11-23.md`](../06_evidence/扩量公开基准与全功能对比报告-2026-11-23.md) | PASS |
| 常驻 `TaskScope` 峰值内存稳定性（6 题测试范围） | `VmHWM = 88.0 MiB`（相对冷启动 87.8 MiB 仅 `+0.25 MiB`），`zero_residual = true` | [`../06_evidence/real_gaps_closed_nuc.json`](../06_evidence/real_gaps_closed_nuc.json) | PASS |
| 显式能力边界 | ① 桌面控制（`VMController`）仍为内存态模拟；② 子集实验非官方榜单；③ 固定响应桩单并发四工程链路下 Runtime 仍略慢于直接编排（`+6.1%~+7.6%`），尚未证明所有场景均快于直接调用 | 全材料一致注明 | 已注明 |

- **R6 正式封板日期**：2026-11-25
- **队伍确认签字**：______________________
