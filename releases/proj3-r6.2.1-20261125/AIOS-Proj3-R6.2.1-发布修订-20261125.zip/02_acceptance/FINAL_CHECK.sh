#!/bin/bash
set -euo pipefail
# openEuler 24.03 SP4 One-Click Acceptance Script (Offline, Zero Paid API Calls)
PKG_DIR="$(cd "$(dirname "$0")/.." && pwd)"
PYTHON_BIN="$("${AIOS_PYTHON:-python3}" -c 'import sys; print(sys.executable)')"
if [ "${1:-}" != "" ]; then
  echo "Note: ignoring custom path '$1' for safety; extracting into an isolated temporary directory."
fi
WORK_DIR="$(mktemp -d "${TMPDIR:-/tmp}/aios-proj3-accept.XXXXXX")"
trap 'rm -rf "$WORK_DIR"' EXIT
echo "Using Python interpreter: $PYTHON_BIN"

echo "=== [1/4] Verify SHA-256 integrity ==="
"$PYTHON_BIN" "$PKG_DIR/02_acceptance/verify_delivery.py" "$PKG_DIR"

echo "=== [2/4] Extract frozen source to isolated temp dir: $WORK_DIR ==="
"$PYTHON_BIN" -m zipfile -e "$PKG_DIR/01_source/aios-proj3-v2.0-FROZEN.zip" "$WORK_DIR"

cat > "$WORK_DIR/_run_delegated.sh" << 'EOF'
#!/bin/bash
set -euo pipefail
WORK_DIR="$1"
MODE="$2"
PYTHON_BIN="$3"
CG_REL="$(cut -d: -f3 /proc/self/cgroup | head -n 1)"
CG_ROOT="/sys/fs/cgroup${CG_REL}"
mkdir -p "${CG_ROOT}/aios_self" "${CG_ROOT}/workers"
echo $$ > "${CG_ROOT}/aios_self/cgroup.procs"
echo "+cpu +memory +pids" > "${CG_ROOT}/cgroup.subtree_control"
echo "+cpu +memory +pids" > "${CG_ROOT}/workers/cgroup.subtree_control"
cd "$WORK_DIR"
if [ "$MODE" = "tests" ]; then
  AIOS_TEST_CGROUP_ROOT="${CG_ROOT}/workers" "$PYTHON_BIN" -B -m unittest discover -s tests -v
else
  "$PYTHON_BIN" -B tools/validate_linux.py
fi
EOF
chmod +x "$WORK_DIR/_run_delegated.sh"

echo "=== [3/4] Run full 111-test suite (incl. 15 boundary + 5 guardrail + 5 delivery review + 9 R3 + 3 R6 invariant tests) inside delegated cgroup v2 ==="
systemd-run --user --wait --pipe --collect -p Delegate=yes /bin/bash "$WORK_DIR/_run_delegated.sh" "$WORK_DIR" tests "$PYTHON_BIN"

echo "=== [4/4] Run validate_linux.py (CPU 0.2 core throttle, OOM kill, zero orphan cgroups) ==="
systemd-run --user --wait --pipe --collect -p Delegate=yes --working-directory="$WORK_DIR" "$PYTHON_BIN" -B tools/validate_linux.py

echo "=== AIOS_PROJ3_ACCEPTANCE_PASSED ==="
