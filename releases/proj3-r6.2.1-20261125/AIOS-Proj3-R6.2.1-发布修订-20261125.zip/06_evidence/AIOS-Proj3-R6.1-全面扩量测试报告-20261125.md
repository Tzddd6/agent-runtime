# AIOS Proj3 (R6.1 终版) 全面扩量实机测试报告

- **测试日期**：2026-11-25
- **受测冻结版本**：`aios-proj3-v2.2-R6-111tests-FROZEN`（源包 SHA-256 `f4cbc22d4b64a348726f9860cdc13f2c6162e0eee91fef33dead263237b8a1c8`；本次测试完全在独立目录 `d:\gemini\aios_expanded_tests` 运行，主仓与 R6.1 封板包零改动）
- **实机环境**：openEuler 24.03 SP4（Linux `6.6.0-159.4.20.174.oe2403sp4.x86_64`, Python 3.11.6, `cgroup v2` 委派模式）+ 本机 Chromium 无头浏览器
- **总 API 实际消耗**：板块 1 & 4 为 ¥0（离线）；板块 2 & 3 共计 **552 次真实 `deepseek-chat` 调用**，按官方无缓存上限估算总费用仅 **¥0.9197**（远低于 ¥30 预算红线）

---

## 板块 1：NUC 真机 OS 级混沌与极限压测（离线，¥0）

原始证据：`track1_nuc_os_chaos_stress.json`

| 子项 | 实验设计 | NUC openEuler 24.03 SP4 实测结果 | 结论 |
|---|---|---|---|
| **1A：委托 `cgroup v2` 并发争用 + 真实 OOM 尖峰攻击** | 6 个健康 `ProcessService` Worker + 2 个 180 MiB 恶意内存尖峰进程（限额 `32 MiB`、`swap=0`）并发运行 | 健康组 **6/6 通过**；恶意组 **2/2 触发 Linux 内核真实 OOM 击杀（`returncode=-9`, `oom_kill=1`×2）**，宿主内核零受累；关闭后 `leftover_dirs=[]`（`zero_orphan_cgroups_after_close=true`） | **PASS** |
| **1B：内核高并发扩展压测（`200 → 500 → 1000` 并发，本地 mock 桩）** | 多线程并发提交 `LLMQuery(model="mock-aios-core")`，采集吞吐、P50/P95/P99 与 `/proc/self/status` `VmHWM` | • 200 并发：200/200，`0.0704s`，**2,839.3 req/s**，P50 `22.14ms` / P99 `32.73ms`，`VmHWM=40.32 MiB`<br>• 500 并发：500/500，`0.1840s`，**2,717.7 req/s**，P50 `43.68ms` / P99 `53.56ms`，`VmHWM=42.43 MiB`<br>• 1,000 并发：**1000/1000（100%）**，`0.3915s`，**2,554.3 req/s**，P50 `47.25ms` / P95 `53.32ms` / P99 `56.59ms`，`VmHWM=43.79 MiB` | **PASS** |
| **1C：60 轮长周期浸泡 + 3 次真实 `SIGKILL` 混沌注入** | 连续 60 轮 `TaskScope` + `ContextStore`（WAL+FULL）+ `AF_UNIX` 常驻 Worker，在第 15/30/45 轮直接 `kill -9` 常驻 Worker | **60/60 轮通过**（`0.516s`）；**3/3 次 `SIGKILL` 崩溃自动拉起新 PID 并正常返回**；第 1/20/40/60 轮 `VmHWM` 恒定 **`43.79 MiB`（+0.00 MiB）**，`remaining_context_objects=0` | **PASS** |

---

## 板块 2：R6.1 共享协议「真实 DeepSeek 3 对 ABBA 公平交替对照」（NUC，~¥0.114）

原始证据：`track2_nuc_real_deepseek_fair_abba.json`（38,016 字节，含每轮提示词 SHA-256、真实计费 Token 与 Worker 回执）

- **实验条件**：`concurrency=1`、`temperature=0.0`、`max_output_tokens=4096`、`max_patch_rounds=2`，共享 `runtime/engineering_protocol.py` 与相同隔离 `ProcessService`，覆盖 4 个工程（`order_service`、`pricing`、`intervals`、`text_normalization`），ABBA 交错 3 对。

| 指标 | Arm A (`AIOS_RUNTIME`) | Arm B (`DIRECT_LOOP`) | 归因说明 |
|---|---:|---:|---|
| 首轮提示词 SHA-256 逐对一致 | `[true, true, true]` | `[true, true, true]` | 双方输入完全一致 |
| 真实修复通过率 | **12 / 12（100%）** | **12 / 12（100%）** | 双方全部一轮通过公开+隐藏测试与交付 ZIP 复验 |
| 真实模型调用次数 | **12 次** | **12 次** | 完全一致 |
| 真实计费 Prompt Tokens | **15,963** | **15,963** | **零 Token 膨胀（逐 Token 相等）** |
| 真实计费 Completion Tokens | **3,162** | **3,162** | **完全相等** |
| 端到端耗时中位数（3 轮） | **6.46 s**（6.26 / 6.46 / 6.89s） | **7.13 s**（7.13 / 16.37 / 6.64s） | 真实云端 HTTPS 网络耗时占主导，AIOS 约 86ms 本地协调开销摊薄至约 1.3%（不据此宣称单并发更快，如实记录 Arm B 第 2 轮云端尾延迟 `16.37s`） |

---

## 板块 3：扩量公开基准集 + Bare 对照（NUC，真实 `deepseek-chat`，~¥0.805）

原始证据：`track3_nuc_expanded_public_benchmarks.json`（528 次调用，累计 129,282 input tokens / 68,344 output tokens）

*(口径说明：均在自托管受控框架下运行，不代表官方榜单成绩；本次 AIOS 为 6 路并发多路复用 `ModelService`，Bare 为 2 路并发直接 HTTPS，吞吐加速比对应 6 路 vs 2 路并发配置。)*

| 公开基准 | 题量 | AIOS（6 路多路复用） | Bare（2 路直接 HTTPS） | 并发耗时比 | 失败集与归因 |
|---|---:|---|---|---:|---|
| **BFCL v4 Parallel** | **100 题**（原 30 题的 3.3×） | **89 / 100（89.0%）**<br>`20.41s`，排队 `0.331ms`，零 `502` | **89 / 100（89.0%）**<br>`58.48s` | **2.86×** | `identical_failed_set = true`：11 道错题编号**100% 完全一致**，零 Runtime 引入失败 |
| **HumanEval 全量** | **164 / 164 题**（原 20 题的 8.2×，官方全集） | **154 / 164（93.90%）**<br>`39.85s`，排队 `0.267ms`，零 `502` | **157 / 164（95.73%）**<br>`82.31s` | **2.07×** | 7 题错题重合；AIOS 另多 3 题失败（`HumanEval/1, 20, 32`，其中 `HumanEval/32` 为官方随机多项式求根题，单次云端采样波动，零 HTTP/502 错误；如实记录差异） |

---

## 板块 4：多模型切换 + 多并发 Web 端到端压测（离线，¥0）

原始证据：`track4_web_concurrent_stress.json`

| 子项 | 实测结果 | 状态 |
|---|---|---|
| **4A：多模型 Profile 切换与零明文泄露** | 依次保存并切换 `deepseek-chat`、`qwen-plus`、`glm-4-plus` 3 套配置（合成测试值，零外网请求）：`3/3` 成功切换，`zero_raw_key_leak = true` | **PASS** |
| **4B：10 客户端并发提交互斥 + 160 并发读压测** | 10 路同时 `POST /api/jobs`：严格仅放行 **1 个任务（`succeeded`）**、其余 **9 路返回 `400`** 拒绝冲突；160 路并发读请求 **160/160 返回 200 OK（P50 `4.86ms`）** | **PASS** |
| **4C：多浏览器会话并发渲染与刷新恢复** | 3 个独立 Chromium 会话加载与刷新 `/console/`：**`3/3` 零 `pageerror`** | **PASS** |
