# AI 工具辅助声明与团队原创性说明

1. **原创架构与实验归属**：本项目的系统总体架构设计、openEuler `cgroup v2` 委托硬隔离方案、多路复用纯内存持钥进程、`AF_UNIX` 常驻监督与 5 套公开任务子集 + 1 套合成压测的 Bare 对照实验设计均由参赛队伍主导完成，所有性能与通过率数据均在真实 openEuler 24.03 SP4（NUC）硬件上独立实测获得，绝无伪造或外推。
2. **AI 辅助范围与核验口径**：在工程开发、边界用例排查、文档排版与图表脚本编写过程中使用了 AI 编程助手（详见 `06_evidence/AI工具使用说明_赛制合规10分项.md`，严格遵循“可核实才写、未知写未知”原则）。团队对核心架构决策、关键缺陷修复（含 `OA-01`~`OA-05` 及 R3 六文件合龙）执行了多轮自动化回归（NUC 第一阶段 108/108 零跳过）、独立验收核查与 Playwright 6/6 浏览器验收；对于未单独留存逐行签字记录的辅助脚本，不作“逐行人工审计”之类的过度承诺。
3. **开源致谢与引用**：本系统严格遵循相关开源协议，对 `agiresearch/AIOS`、`eunomia-bpf/agentcgroup`、`THUDM/AgentBench`、`sierra-research/tau2-bench`、`ShishirPatil/gorilla (BFCL)`、`openai/human-eval`、`google-research/mbpp` 与 `AgentRace` 等公开基准与学术工作均在技术报告中规范引用。
