# AIOS：面向多 Agent 协同的 openEuler 操作系统级智能体运行时

**2026 年全国大学生计算机系统能力大赛 · 操作系统设计赛（功能挑战赛 proj3）技术报告与论文（修订定稿版）**

- **运行平台**：openEuler 24.03 SP4（Linux 6.6.0，cgroup v2 unified）
- **评测口径**：自托管受控子集 A/B 对照（`deepseek-chat`，严格区分模型能力与 Runtime 增量）
- **封板日期**：2026-11-23

## 摘要

面向 2026 年全国大学生计算机系统能力大赛操作系统设计赛（功能挑战赛 proj3：面向多 Agent 协同的操作系统级智能体运行时），本团队在 openEuler 24.03 SP4（Linux 6.6.0）上设计并实现了操作系统级智能体运行时 AIOS。

区别于传统仅停留在应用层脚本编排的 Agent 框架，AIOS 从内核资源隔离、多路复用密钥隔离、常驻进程自愈与零拷贝上下文共享四个操作系统维度进行系统重构：（1）基于 Linux cgroup v2 委托子树实现 CPU（实测 0.2032 核限流）、内存 OOM 隔离与退出零孤儿目录回收；（2）实现基于请求 ID 多路复用 IPC 与 16 线程池的纯内存持钥进程 ModelService，在业务子进程零 API Key 继承的前提下将 4 并发真实 DeepSeek API 耗时从 4.916s 压缩至 0.542s（相对旧版单 Pipe 锁实现提速 9.07×）；（3）构建基于 Linux AF_UNIX Unix Domain Socket 的常驻 OS Worker 心跳监督与 SIGKILL 崩溃自动拉起机制；（4）引入引用计数 TaskScope、SHA-256 零拷贝 ContextStore 与动态二轮 DAG 容错修复节点，并集成 A-Mem、LSFS、AgentHub 及内存态 LiteCUA GUI 模拟沙箱等前沿论文生态子系统。

在评测方法上，借鉴效率评测工作 AgentRace（2025），我们在 openEuler 24.03 SP4 真机上基于 5 套 GitHub 公开基准的原始任务数据集与真值（BFCL v4 Parallel、HumanEval、MBPP、AgentBench OS、tau2-bench Airline）以及本项目 5→200 合成并发压测，在自托管受控评测框架下构建了 Bare 直接 HTTPS 对照组（注：均属受控子集复现实验，不代表官方榜单成绩）。实测表明：NUC 全量 89/89 单元测试（含 15 项独立边界用例）零跳过通过；本项目合成并发压测 200 并发 Agent 达 100% 通过率（0.1076s，1,858.8 req/s，VmHWM=41.6 MiB）；在真实云端受控对照中，BFCL 30 题（83.3%）与 MBPP 20 题（90.0%）失败题集与 Bare 一致且耗时分别快 1.66× 与 1.11×~1.46×；AgentBench OS 26 题修复截断预算并开启 4 路并发后达到 16/26（61.54%，与 Bare 持平）且耗时比 Bare 快 1.88×（67.29s vs 126.40s）；tau2-bench 20 题开启 4 路并发后相对旧版串行 AIOS 自身提速 3.18×（319.23s → 100.26s，零 502 错误；通过率由旧版 16/20 变为 15/20，单次运行未做多次重复统计检验，如实记录差异）；在 6 题连续常驻 TaskScope 对照范围内，峰值内存 VmHWM 稳定在 88.0 MiB（相对冷启动 87.8 MiB 仅 +0.25 MiB）且 zero_residual=True，未观测到内存持续增长。

## 1. 引言与问题定义

大语言模型（LLM）正从单轮问答演进为长周期、多工具、多智能体协同的系统级工作负载。现有主流应用层框架普遍将多 Agent 运行在单一 Python 进程中，缺乏操作系统级别的资源硬边界、并发调度原语与故障隔离机制，导致四类工程痛点：（1）失控工具或死循环可能拖垮宿主进程且缺乏 CPU/内存配额硬约束；（2）共享凭据使工具子进程存在 API Key 暴露风险，而简单单锁隔离又会在并发场景下引发串行瓶颈；（3）上下文重复序列化带来通信开销与资源残留风险；（4）缺乏将“模型推理能力”与“运行时系统效率”解耦的对照评测方法。

针对 proj3 赛题在 openEuler 24.03 SP4 下的要求，本系统将智能体抽象为受控 OS 实体，统一提供 LLM、Memory、Storage、Tool 四类系统调用，并以可复现的真机实测与 Bare 对照组给出严格边界内的量化验证。

## 2. 相关工作与 2025–2026 前沿论文综述

本系统参考并工程化吸收了 2025–2026 年智能体操作系统与效率评测领域的 7 项代表性工作：

• AIOS: LLM Agent Operating System (Mei et al., COLM 2025)：提出将 LLM 调度、上下文切换、内存与工具调用下沉为内核 Syscall 层；本系统在此基础上补齐了 openEuler cgroup v2 硬隔离、DRF 公平配额与零空等队列调度。

• Cerebrum (AIOS SDK) (NAACL 2025) & LLM as OS, Agents as Apps (arXiv:2312.03815)：提出智能体应用生态与声明式权限清单；本系统实现了 AgentHub 与 AgentManifest 权限沙箱，拦截未声明的系统调用与工具访问。

• From Commands to Prompts: LSFS (ICLR 2025)：提出基于语义的智能体文件系统；本系统实现了 IntentRouter 自然语言到文件 Syscall 路由、版本回滚、分享链接与 403 路径穿越拦截。

• A-Mem: Agentic Memory for LLM Agents (arXiv:2502.12110)：提出卡片盒（Zettelkasten）式动态记忆演进网络；本系统实现了双向语义链接、邻居标签演进与 1-hop 图谱联想召回。

• LiteCUA: Computer as MCP Server (arXiv:2505.18829)：提出无障碍树 GUI 观测与状态快照协议；本系统在 aios/tool/litecua_vm.py 中实现了内存态无障碍树与 GUI 状态机模拟沙箱（用于验证观测、点击/输入与快照回滚协议，未接管 NUC 真实物理桌面）。

• AgentRace: Benchmarking Efficiency in LLM Agent Frameworks (2025)：指出仅看任务准确率不足以评价 Agent 框架，需从延迟、并发吞吐、通信负载与工具校验开销等维度评估 Runtime 效率。受其启发，本系统建立了 Bare 直接调用对照组，把模型准确率和 Runtime 系统效率增量分离呈现。

## 3. 系统总体架构与操作系统核心原语

AIOS 采用五层分层架构：应用与生态层（AgentHub / Web Console / Cerebrum SDK）→ 编排与工作流层（WorkflowEngine 动态 DAG 与二轮容错派生）→ 调度与控制面（FIFO/RR + DRF 公平配额 + 事件驱动零空等队列）→ 四大系统调用子系统（LLM / Memory / Storage / Tool）→ Linux 操作系统原语层（cgroup v2 委托子树、AF_UNIX 常驻 Worker 监督器、RAM-Only 多路复用持钥进程）。

3.1 请求 ID 多路复用纯内存持钥进程（ModelService）：为兼顾内存态密钥隔离与高并发吞吐，ModelService 在独立 spawn 子进程内仅于 RAM 保存供应商凭据（业务 Worker 环境变量零 API Key 继承），并通过“请求 ID 多路复用 Pipe + 子进程 16 线程池 + 父进程异步解复用线程”破除单 Pipe 锁串行瓶颈。

3.2 Linux cgroup v2 硬隔离与 AF_UNIX 常驻 Worker 自愈：工具执行通过 ProcessService 注入 openEuler 委托 cgroup v2 子树（cpu.max、memory.max、pids.max），实测 CPU 限流 0.2032 核、OOM 触发 oom_kill=1 且退出零孤儿目录；WorkerSupervisor 在 Linux 下通过原生 AF_UNIX Socket 维护常驻 Worker 心跳与 VmRSS 遥测，检测到 SIGKILL 崩溃后自动拉起新进程且不静默重放未确认写操作。

3.3 引用计数 TaskScope、零拷贝 ContextStore 与动态二轮 DAG：TaskScope 实现作用域互斥与退出自动清理；ContextStore 采用 SHA-256 去重与引用计数租约，支持两阶段 SQLite 原子删除回滚；WorkflowEngine 在工程修复首轮独立单测失败时动态注入 patch_round_2 -> verify_round_2 节点并接入 review，形成有界无环自愈闭环。

![图 1：多路复用纯内存持钥进程（ModelService）真实 DeepSeek API 4/8 并发耗时与吞吐对比（相对旧版单 Pipe 锁提速 9.07×）。](charts/fig1_model_service_speedup.png)
*图 1：多路复用纯内存持钥进程（ModelService）真实 DeepSeek API 4/8 并发耗时与吞吐对比（相对旧版单 Pipe 锁提速 9.07×）。*

## 4. 对抗性可靠性工程与 fail-closed 安全契约

封板前，系统经历了两轮独立边界测试与对抗性复核，关闭了 12 项深层边界缺陷：包括多作用域共享上下文误删（引入 _holders 引用计数）、同名作用域凭据覆盖（引入 _active_scopes 互斥锁）、SQLite 提交失败破坏内存/磁盘一致性（改为两阶段删除与回滚）、IPC 凭据撤销后仍可调用、无界云端执行池积压（引入 BoundedSemaphore）、内核 stop() 遗漏在途请求取消通知（全队列 503 排空），以及损坏日志管道（BrokenPipeError）中断业务执行等。

在 Bare 对照组审计中，我们进一步验证了 adapter.py 的 fail-closed 截断守卫契约（test_native_tau_bridge.py 专项锁定）：当模型因 max_tokens 偏紧返回 finish_reason='length' 时，Runtime 主动返回 502 拒绝执行半截 Shell 命令或残缺 JSON 工具调用；在将多轮评测脚本的 Token 预算调至合理上限（1536）后，全部 116 道真实云端任务实现零 502 误杀。

![图 2：Linux /proc/self/status 常驻峰值内存 VmHWM 实测（左，6 题测试范围内仅 +0.25 MiB）与 openEuler cgroup v2 CPU 硬限流实测（右）。](charts/fig5_rss_and_cgroup_isolation.png)
*图 2：Linux /proc/self/status 常驻峰值内存 VmHWM 实测（左，6 题测试范围内仅 +0.25 MiB）与 openEuler cgroup v2 CPU 硬限流实测（右）。*

## 5. 实机评测与严格双维度归因（openEuler 24.03 + DeepSeek）

评测口径说明：以下实验均在 NUC（openEuler 24.03 SP4，Linux 6.6.0，Python 3.11.6）上使用真实 deepseek-chat 完成。各公开基准均采用官方公开原始任务集与真值，但在自托管 AIOS/Bare 对照框架中适配了统一工具调度器与评测脚本，因此结果代表受控子集 A/B 对比，而非官方排行榜成绩。

5.1 NUC 全量回归与全功能子系统矩阵：委托 cgroup v2 下 89/89 单元测试（含 15 项独立边界用例）全部通过（0 跳过）；AF_UNIX 常驻 Worker SIGKILL 自愈（PID 63126 -> 63128）、ModelService 8 并发 8/8（1.115s，7.17 calls/s）、A-Mem 1-hop 召回、LSFS 版本回滚与 403 路径穿越拦截、内存态 LiteCUA 模拟沙箱快照恢复、AgentHub Manifest 权限拦截与 Mailbox ACL 撤销全部实机通过。

5.2 合成并发压测与五套受控公开基准子集三方对比（通过率 + 耗时）：

• 本项目合成并发压测（5 → 200 并发，本地 mock-aios-core 桩）：200/200（100%），耗时 0.1076s，吞吐 1,858.84 req/s，VmHWM 41.6 MiB（反映本地内核调度与队列吞吐）。

• BFCL v4 Parallel 子集（30 题）：AIOS 25/30（83.3%，6.46s，内核排队 0.467ms）vs Bare 25/30（83.3%，10.74s）——两者失败题号集合一致（parallel_3/9/19/26/29），未观测到 Runtime 引入的额外失败（一致性观察），AIOS 并发比 Bare 快 1.66×。

• HumanEval 抽样子集（20 题）：AIOS 19~20/20（7.55~7.86s）vs Bare 连续两次 19/20（7.12s/8.33s），唯一失败题均为官方随机多项式求根题 HumanEval/32。

• MBPP 子集（20 题）：AIOS 18/20（90.0%，4.92~6.44s）vs Bare 18/20（90.0%，7.17s）——两者失败题号集合一致（task_id 13, 15），未观测到 Runtime 引入的额外失败，AIOS 并发比 Bare 快 1.11×~1.46×。

• AgentBench OS 全量 dev.json（26 题）：优化后 AIOS 达到 16/26（61.54%，零 502，67.29s），通过率较优化前（10/26）提升 +23.08 pp 并与 Bare（16/26，126.40s）持平，端到端耗时比 Bare 快 1.88×。

• tau2-bench Airline 子集（20 题）：开启 4 路并发与 1536 Token 预算后实现零 502（458 次系统调用，1,072,224 Tokens），总耗时相对旧版串行 AIOS（319.23s）自身提速 3.18× 至 100.26s（单题均值 15.96s → 5.01s）；通过率由旧版 16/20 变为 15/20（单次运行未做多次重复统计检验，如实记录 1 题差异；Bare 前 14 题对照为 12/14）。在另行开展的 6 题成对对照中，冷启动与常驻 TaskScope+P3 通过率同为 5/6（83.33%），峰值 VmHWM 为 88.0 MiB（相对冷启动 87.8 MiB 仅 +0.25 MiB），单次 Prompt Token 降低 4.18%。

![图 3：四套真实云端受控基准子集 Bare 直接调用 vs AIOS 优化前后 耗时（左）与通过率（右）成对对照。](charts/fig2_bare_vs_aios_latency_acc.png)
*图 3：四套真实云端受控基准子集 Bare 直接调用 vs AIOS 优化前后 耗时（左）与通过率（右）成对对照。*

## 5.3 扩展性与可复现五维能力对照

图 4 展示了本项目合成并发压测从 5 路扩展至 200 路并发 Agent（本地 mock-aios-core 桩）时的吞吐与排队延迟曲线：在 50~200 并发区间吞吐保持在 1,836~1,916 req/s，平均排队等待稳定在 18~21ms，成功率 100%。

图 5 借鉴 AgentRace 的效率评估维度，严格基于本次 NUC 实测 JSON 给出可复现的五维量化对照（AIOS Runtime vs Bare 直接 HTTPS，不含未实测的第三方框架）：① 4 并发实测吞吐 = 10×(calls/s ÷ 7.38)；② 低排队开销 = 10×exp(-wait_ms/10)；③ OS 硬隔离覆盖 = 实测通过项数(最多5项)×2；④ 安全与零拷贝治理 = 实测通过项数(最多5项)×2；⑤ 端到端实测加速 = min(10, 5×BFCL与AgentBench均值加速比)。

![图 4：本项目合成并发压测（5 → 200 并发，本地 mock-aios-core 桩）吞吐与排队延迟曲线（NUC openEuler 24.03）。](charts/fig3_aios_200_concurrency_scaling.png)
*图 4：本项目合成并发压测（5 → 200 并发，本地 mock-aios-core 桩）吞吐与排队延迟曲线（NUC openEuler 24.03）。*

## 6. 总结、能力边界与参考文献

本工作在 openEuler 24.03 SP4 上交付了一个可离线一键复现、经过两轮独立边界复核并纳入 89 项自动化回归的操作系统级多 Agent 运行时 AIOS。需要显式保留并如实说明的能力边界包括：（1）桌面控制（LiteCUA / VMController）当前仍为内存态无障碍树与 GUI 状态机模拟沙箱，未接管 NUC 物理桌面；（2）5 套公开任务子集 + 1 套合成压测均在自托管受控框架下运行，不代表官方榜单成绩；（3）加速结果仅覆盖本次实测的多路并发场景，尚未证明在所有场景（例如单次串行短调用）下均快于直接调用；（4）雷达图采用自定义可复现量化公式，仅用于直观汇总本次实测维度。

参考文献：

[1] Mei, K., et al. AIOS: LLM Agent Operating System. COLM 2025.

[2] Rui, W., et al. Cerebrum (AIOS SDK): A Platform for Agent Development, Deployment, Distribution, and Discovery. NAACL 2025.

[3] Shi, Z., et al. From Commands to Prompts: LLM-based Semantic File System for AIOS (LSFS). ICLR 2025.

[4] Xu, W., et al. A-Mem: Agentic Memory for LLM Agents. arXiv:2502.12110, 2025.

[5] Mei, K., et al. LiteCUA: Computer as MCP Server for Computer-Use Agent on AIOS. arXiv:2505.18829, 2025.

[6] Ge, Y., et al. LLM as OS, Agents as Apps: Envisioning AIOS, Agents and the AIOS-Agent Ecosystem. arXiv:2312.03815.

[7] AgentRace Team. AgentRace: Benchmarking Efficiency in LLM Agent Frameworks. 2025.

[8] Liu, X., et al. AgentBench: Evaluating LLMs as Agents. ICLR 2024.

[9] Barres, V., et al. tau2-bench: Evaluating Conversational Agents in a Dual-Control Environment. 2025.

[10] Patil, S., et al. Berkeley Function Calling Leaderboard (BFCL v4). 2025.

![图 5：借鉴 AgentRace 效率维度的五维能力评估雷达图（基于本次实测配置综合对比）。](charts/fig4_agentrace_5d_radar.png)
*图 5：借鉴 AgentRace 效率维度的五维能力评估雷达图（基于本次实测配置综合对比）。*
