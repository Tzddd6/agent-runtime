# openEuler 24.03 SP4 干净部署与安全验收手册

## 1. 解压与完整性校验
```bash
mkdir -p ~/aios-proj3-final
python3 -m zipfile -e AIOS-Proj3-最终交付候选包-20261123.zip ~/aios-proj3-final
cd ~/aios-proj3-final/AIOS-Proj3-最终交付候选包
sha256sum -c FILES.sha256
```

## 2. 环境与依赖说明（Python 3.11+）
内核基础功能主要依赖 Python 3.11+ 标准库（`sqlite3`、`urllib`、`socket`、`multiprocessing` 等，包内不包含 `requirements.txt`）；**完整附件功能（PDF/图片解析）及对应测试需要 `pymupdf`、`pillow`；Linux 硬隔离测试需要 `cgroup v2` 委派环境**。

在干净环境中建议创建虚拟环境并安装附件依赖：
```bash
python3 -m venv ~/aios-venv && source ~/aios-venv/bin/activate
pip install pymupdf pillow
```
`FINAL_CHECK.sh` 会自动解析当前激活环境（或环境变量 `AIOS_PYTHON`）的 Python 绝对路径，并显式传递给 `systemd-run --user`，避免 `systemd-run` 退回系统默认解释器。

## 3. 一键离线全量验收并导出日志到包外目录（89/89 + cgroup v2 硬隔离 + 零残留）
为避免覆盖包内受 `FILES.sha256` 校验的归档证据文件，请务必将新生成的验收日志导出到**包外目录**并启用 `set -o pipefail`：
```bash
set -o pipefail
bash 02_acceptance/FINAL_CHECK.sh 2>&1 | tee "/tmp/aios-proj3-acceptance-$(date +%Y%m%d-%H%M%S).log"
```
- **安全临时目录**：脚本自动在 `/tmp/aios-proj3-accept.XXXXXX` 创建隔离临时目录并在退出时 `trap` 清理，不会删除用户任何已有目录。
- **零付费调用**：离线验收不依赖任何云端模型 API Key，全部使用本地受控桩与真实 Linux 内核原语（`cgroup v2` 委托子树初始化、`AF_UNIX`、`unshare`）。
- **通过标志**：终端及包外日志输出 `Ran 89 tests ... OK`、`zero_orphan_cgroups: true` 与 `=== AIOS_PROJ3_ACCEPTANCE_PASSED ===`（本包随附的 NUC 历史实机日志位于 `02_acceptance/nuc_final_check.log`，请勿覆盖）。

## 4. Web Console 安全启动与演示规范
```bash
# 解压冻结源码并启动（runtime.web 已固定绑定 127.0.0.1，不支持 --host 参数）
python3 -m zipfile -e 01_source/aios-proj3-v2.0-FROZEN.zip /tmp/aios-web-demo
cd /tmp/aios-web-demo
python3 -m runtime.web --port 8765
```
- 远程访问请使用 SSH 本地端口转发：`ssh -L 8765:127.0.0.1:8765 user@host`，随后在本地浏览器打开 `http://127.0.0.1:8765/console/`。
- 如需在线真实模型演示，API Key 仅通过进程环境变量 `DEEPSEEK_API_KEY` 传入内存态持钥进程（业务子进程环境变量不继承供应商 Key），禁止写入配置文件、终端回显或录屏画面。

## 5. 能力边界说明
1. **桌面控制（LiteCUA / `VMController`）**：当前为内存态无障碍树与 GUI 状态机模拟沙箱，未接管 NUC 物理桌面。
2. **基准口径**：5 套公开任务子集 + 1 套合成压测均在自托管受控框架下运行，不代表官方榜单成绩。
3. **性能边界**：加速数据仅覆盖本次实测多路并发场景，尚未证明在所有场景（如单次串行短调用）下均快于直接调用。
