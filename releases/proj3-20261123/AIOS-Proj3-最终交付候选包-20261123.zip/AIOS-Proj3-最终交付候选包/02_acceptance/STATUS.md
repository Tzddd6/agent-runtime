# AIOS Proj3 实机验收状态与封板签字表

| 验收维度 | 实机结果（openEuler 24.03 SP4） | 状态 |
|---|---|---|
| 全量单元测试（含 Linux `cgroup v2`、`AF_UNIX` 及 15 项独立边界用例） | **89 / 89 通过（0 跳过）**，详见 `02_acceptance/nuc_final_check.log` | PASS |
| `validate_linux.py` 硬隔离验证 | `cpu_core_ratio ≈ 0.208`, `oom_kill = 1`, `zero_orphan_cgroups = true` | PASS |
| 多路复用 `ModelService` 并发（真实 DeepSeek） | 4 并发 `0.542s`（相对旧版单 Pipe 锁提速 9.07×），8 并发 `8/8` (`1.115s`) | PASS |
| 5 套公开任务子集 + 1 套合成压测（Bare 对照） | 本项目 200 并发合成压测 `200/200` (`0.1076s`)；云端全量零 `502`；BFCL 比 Bare 快 1.66×、AgentBench 比 Bare 快 1.88×（追平 16/26）、tau2 相对旧版串行 AIOS 提速 3.18×（16/20→15/20 如实记录单次差异；未证明所有场景均快于直接调用） | PASS |
| 常驻 `TaskScope` 峰值内存稳定性（6 题测试范围） | `VmHWM = 88.0 MiB`（相对冷启动 87.8 MiB 仅 `+0.25 MiB`），`zero_residual = true` | PASS |
| 显式能力边界 | ① 桌面控制（`VMController`）仍为内存态模拟；② 子集实验非官方榜单；③ 尚未证明所有场景均快于直接调用 | 已注明 |

- **封板日期**：2026-11-23
- **队伍确认签字**：______________________
