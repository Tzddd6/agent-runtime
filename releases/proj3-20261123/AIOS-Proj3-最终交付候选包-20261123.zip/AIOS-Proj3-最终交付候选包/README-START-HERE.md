# AIOS Proj3 终版交付候选包 · 评委 3 分钟快速导览

欢迎审阅 **2026 全国大学生计算机系统能力大赛操作系统设计赛（proj3）** 终版交付包！

## 目录结构
- `01_source/`：冻结源码包 `aios-proj3-v2.0-FROZEN.zip` 与 SHA-256 说明
- `02_acceptance/`：openEuler 24.03 一键离线验收脚本 `FINAL_CHECK.sh`、部署手册与验收签字表
- `03_report/`：完整学术级《技术报告与论文》（`.md` / `.docx` / `.pdf`）与 5 张 300-DPI 高清图表
- `04_presentation/`：14 页 16:9 竞赛答辩 PPT（`AIOS-Proj3-答辩PPT.pptx`）
- `05_demo/`：5 分钟演示与录屏脚本 + 12 题评委高频 Q&A 提纲
- `06_evidence/`：openEuler 24.03 NUC 真机实测原始 JSON、Bare 对照组归因数据与系统架构图
- `07_compliance/`：AI 工具使用声明与封板合规检查清单
- `FILES.sha256`：全包所有文件 SHA-256 完整性校验清单

## 一键复现验收（openEuler 24.03 SP4，无需任何 API Key）
```bash
sha256sum -c FILES.sha256
bash 02_acceptance/FINAL_CHECK.sh
```
